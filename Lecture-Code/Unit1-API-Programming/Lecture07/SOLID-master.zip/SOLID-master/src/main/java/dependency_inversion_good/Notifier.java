package src.main.java.dependency_inversion_good;

public interface Notifier {
    public void alertWeatherConditions(String weatherConditions);
}
