package src.main.java.interface_segregation_bad;

public interface Bird {
    public void fly();
    public void molt();
}
