package src.main.java.interface_segregation_good;

public interface FeatheredCreature {
    public void molt();
}
