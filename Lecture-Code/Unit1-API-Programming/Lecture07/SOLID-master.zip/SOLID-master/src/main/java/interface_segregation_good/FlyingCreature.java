package src.main.java.interface_segregation_good;

public interface FlyingCreature {
    public void fly();
}
