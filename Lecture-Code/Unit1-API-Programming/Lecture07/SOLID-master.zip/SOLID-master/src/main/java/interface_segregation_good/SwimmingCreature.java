package src.main.java.interface_segregation_good;

public interface SwimmingCreature {
    public void swim();
}
