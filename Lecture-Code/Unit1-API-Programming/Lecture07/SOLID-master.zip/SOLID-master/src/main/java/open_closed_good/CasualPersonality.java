package src.main.java.open_closed_good;

public class CasualPersonality implements Personality {
    public String greet() {
        return "Sup bro?";
    }
}
