package src.main.java.open_closed_good;

public class FormalPersonality implements Personality {
    public String greet() {
        return "Good evening, sir.";
    }
}
