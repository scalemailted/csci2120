package src.main.java.open_closed_good;

public class IntimatePersonality implements Personality {
    public String greet() {
        return "Hello Darling!";
    }
}
