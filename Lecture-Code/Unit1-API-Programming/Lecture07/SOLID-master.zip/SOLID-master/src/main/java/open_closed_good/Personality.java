package src.main.java.open_closed_good;

public interface Personality {
    public String greet();
}
